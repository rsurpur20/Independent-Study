//
//  FinancesViewController.swift
//  independentstudy
//
//  Created by Roshni Surpur on 3/7/21.
//

import UIKit
//import class Order


class FinancesViewController: UIViewController {

    @IBOutlet weak var topText: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        var ex = Order(orderNames: ["jewelry","earring"], orderPrices: [4.56,6.78], orderDate: Date())
//        print(e)
        topText.text="$"+String(ex.getTotal())
        print(ex.orderTime)
    }
//
//    func createOrder() -> [Order]{
////        for order in list of orders, get the total and add up all the totals
//    let example1 = Order()
//        example1.orderList[0][0]="necklace"
//        example.orderList[0][1]=5.42
//
//    return example1
//
//    }

   
    
    
}
