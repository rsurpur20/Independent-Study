//
//  FinancesViewController.swift
//  independentstudy
//
//  Created by Roshni Surpur on 3/7/21.
//
import SwiftUICharts
import UIKit
import SwiftUI
//import class Order


class FinancesViewController: UIViewController {
//    var barChart = BarChartView()/
    @IBOutlet weak var chartidk: UIImageView!
    @IBOutlet weak var topText: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
//        var variable = ChartData(values: [("2018 Q4",63150), ("2019 Q1",50900)])
//         var notsure = BarChartView(data: variable, title: "Title", legend: "Legendary") // legend is optional
//        print(notsure)
////        barChart.delegate=self
        var ex = Order(orderNames: ["jewelry","earring"], orderPrices: [4.56,6.78], orderDate: Date())
//        print(e)
        topText.text="$"+String(ex.getTotal())
        print(ex.orderTime)
    }
//
    struct ContentView: View {
        var body: some View {
            ScrollView{
                VStack{
                    BarChartView(data: ChartData(points: [8,23,54,32,12,37,7,23,43]), title: "Title", style: Styles.barChartStyleNeonBlueLight, form: ChartForm.small)
                        BarChartView(data: ChartData(points: [8,23,54,32,12,37,7,23,43]), title: "Title", style: Styles.barChartStyleOrangeLight, form: ChartForm.large)
    //                BarChartView(data: [8,23,54,32,12,37,7,23,43], title: "Title", style: Styles.barChartStyleOrangeLight, form: Form.medium)
                }
            }//.edgesIgnoringSafeArea(.all)
            
        }
    }

    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }

//    func createOrder() -> [Order]{
////        for order in list of orders, get the total and add up all the totals
//    let example1 = Order()
//        example1.orderList[0][0]="necklace"
//        example.orderList[0][1]=5.42
//
//    return example1
//
//    }

   
    
    
}
