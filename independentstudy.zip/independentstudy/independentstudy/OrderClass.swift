//
//  OrderClass.swift
//  independentstudy
//
//  Created by Roshni Surpur on 3/7/21.
//

import Foundation

class Order{
    var orderListNames = ["necklace","earring"]
    var orderListPrices = [5.43,3.24]
    var orderTime = Date()
    
    init(orderNames : Array<String>, orderPrices : Array<Double>, orderDate: Date) {
        orderListNames.append(contentsOf: orderNames)
        orderListPrices.append(contentsOf: orderPrices)
        var orderTime = orderDate
    }
    
    func getTotal() -> Double {
        var total=0.0
        for order in orderListPrices{
            total = total + order
        }
        return total
    }
    
    
}
