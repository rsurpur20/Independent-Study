//
//  OrdersViewController.swift
//  independentstudy
//
//  Created by Roshni Surpur on 3/15/21.
//

import UIKit

class OrdersViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableViewOrders: UITableView, numberOfRowsInSection section: Int) -> Int {
        return names.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableViewOrders.dequeueReusableCell(withIdentifier: "cell1", for: indexPath)
        
        cell.textLabel?.text = names[indexPath.row]
        
        return cell
    }
    

    @IBOutlet var tableViewOrders: UITableView!
    
    let names = [
    "youre so close",
        "im so proud"," woo hoo"
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tableViewOrders.delegate = self
        tableViewOrders.dataSource = self
    }

    
}
