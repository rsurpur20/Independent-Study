//
//  OrdersViewController.swift
//  independentstudy
//
//  Created by Roshni Surpur on 3/15/21.
//

import UIKit

class OrdersViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableViewOrders: UITableView, numberOfRowsInSection section: Int) -> Int {
        return names.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableViewOrders.dequeueReusableCell(withIdentifier: "cell1", for: indexPath)
//
//        cell.textLabel?.text = names[indexPath.row]
//
//        return cell
        
        let cell = tableViewOrders.dequeueReusableCell(withIdentifier: "cell1", for: indexPath)
//        if completeness[indexPath.row] == false{
//            cell.textLabel?.textColor = UIColor.red
//        }else {
//            cell.textLabel?.textColor = UIColor.green
//        }
        
        cell.textLabel?.text = names[indexPath.row]
        return cell
        
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(identifier: "DetailViewController") as? DetailViewController
        
//        if indexPath.row  > 0 {
        vc?.name = names[indexPath.row]
        if completeness[indexPath.row] == false{
            vc?.complete = "Not Complete!"
        }else {
            vc?.complete = "Complete!"
        }
        
        vc?.receipt = totals[indexPath.row]
//        }
//        else{
//        vc?.name = names[indexPath.row]
//        }
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        let completed = completeAction(at: indexPath)
        return UISwipeActionsConfiguration(actions: [completed])
    }
    
    func completeAction(at indexPath: IndexPath) -> UIContextualAction{
//        completeness[indexPath.row] = true
        
        let action = UIContextualAction(style: .normal, title: "Complete") { (action, view, completion) in
            self.completeness[indexPath.row] = !self.completeness[indexPath.row]
//            if self.completeness[indexPath.row] == false{
//                self.cell.textLabel?.textColor = UIColor.red
//            }else {
//                self.cell.textLabel?.textColor = UIColor.green
//            }
            
            completion(true)
        }
        return action
    }

    @IBOutlet var tableViewOrders: UITableView!
    
//    @IBOutlet weak var lblLeft: UILabel!
    //    let names = [
//    "John Smith                                       ⭕️",
//        "Di'Anna                                             ✅",
//        "Krystal                                              ✅"
//    ]
    
        let names = [
        "John Smith",
            "Di'Anna",
            "Krystal"
        ]
    
    let totals = ["13.56","5.67","34.60"]
    
    var completeness = [false, false, true]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tableViewOrders.delegate = self
        tableViewOrders.dataSource = self
    }
    
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return names.count
//    }
    
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return names.count
//    }
    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as ? CellTableViewCell
//
//        return cell!
//    }

    
}

//extension ViewController: UITableViewDelegate, UITableViewDataSource {
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return names.count
//    }
//
////    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
////        return names.count
////    }
//
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as ? CellTableViewCell
//
//        return cell!
//    }
//}
